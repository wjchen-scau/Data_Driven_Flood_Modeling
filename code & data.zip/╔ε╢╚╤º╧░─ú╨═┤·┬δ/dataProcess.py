# -*- coding: utf-8 -*-
"""
Created on Thu Mar 18 09:05:15 2021
该模块包含的主要是数据处理函数，用于模拟前中后处理
@author: dell
"""
import numpy as np
import pandas

#标准化函数
def normalization(data):
    rangeV=np.max(data)-np.min(data)
    return (data-np.min(data))/rangeV

def normalization_ab(data):
    x_mean = data - np.mean(data)  
    return (data-x_mean) / (np.max(data)-np.min(data)) 

#反标准化函数
def normalization_reverse(data_pre_norl,data_predict):
    rangeV=np.max(data_pre_norl)-np.min(data_pre_norl)
    return data_predict*rangeV+ np.min(data_pre_norl)

#数据处理函数
def depth_data_process(table_path):
    
    #读取数据
    dataframe = pandas.read_table(table_path,header=None,sep=' ')
    dataset = dataframe.values
    dataset = np.nan_to_num(dataset)
    
    #存储dem数据
    n_dem_col=197
    n_dem_row=185
    dem=np.empty([n_dem_row,n_dem_col], dtype = float) 
    for k in range(n_dem_col):
        for j in range(n_dem_row):
            dem[j,k]=dataset[j,k].astype('float')
    
    #读取并存储水深数据
    n_sample_col=n_dem_col #每个淹没分布图/地形图的列数
    n_sample_row=n_dem_row #每个淹没分布图/地形图的行数
    n_sample=15 #总共有18张淹没分布图
    depth_sample=np.empty([n_sample,n_sample_row,n_sample_col],dtype=float)
    for i in range(n_sample):
        depth_sample[ i, :, :]=dataset[(i+1)*185:(i+2)*185,:].astype('float')
    
    return dem, depth_sample
    
#降雨数据处理函数
def raindata_process(table_path):
    dataframe = pandas.read_table(table_path,header=None,sep=' ')
    dataset = dataframe.values
    dataset = np.nan_to_num(dataset)
    n_dem_col=12
    n_dem_row=18
    rain=np.empty([n_dem_row,n_dem_col], dtype = float) 
    for k in range(n_dem_col):
        for j in range(n_dem_row):
            rain[j,k]=dataset[j,k].astype('float')
    return rain

#处理除dem外的地形特征数据
def data_process(table_path):
    dataframe = pandas.read_table(table_path,header=None,sep=' ')
    dataset = dataframe.values
    dataset = np.nan_to_num(dataset)
    n_dem_col=197
    n_dem_row=185
    dataTensor=np.empty([n_dem_row,n_dem_col], dtype = float) 
    for k in range(n_dem_col):
        for j in range(n_dem_row):
            dataTensor[j,k]=dataset[j,k].astype('float')
    return dataTensor

#建立样本后，采用旋转和翻转扩充depth数据
def data_augmentation_depth(scnNum,sample_per_scn,patch_row_col_Num,depth_input):
    temp=np.empty([patch_row_col_Num,patch_row_col_Num], dtype = float) 
    for k in range(scnNum*sample_per_scn):
        temp[:,:]=depth_input[k, :,:, 0]
        depth_input[scnNum*sample_per_scn+k, :,:, 0]=np.rot90(temp,k=1,axes=(1,0))#axes=(1,0)顺时针，axes=(0,1)逆时针
        depth_input[2*scnNum*sample_per_scn+k, :,:, 0]=np.rot90(temp,k=2,axes=(1,0))
        depth_input[3*scnNum*sample_per_scn+k, :,:, 0]=np.rot90(temp,k=3,axes=(1,0))
        depth_input[4*scnNum*sample_per_scn+k, :,:, 0]=np.flip(temp,axis=0)
        depth_input[5*scnNum*sample_per_scn+k, :,:, 0]=np.rot90(np.flip(temp,axis=0),k=1,axes=(1,0)) #axis=0沿x轴翻转，axis=1沿y轴翻转
        depth_input[6*scnNum*sample_per_scn+k, :,:, 0]=np.rot90(np.flip(temp,axis=0),k=2,axes=(1,0))
        depth_input[7*scnNum*sample_per_scn+k, :,:, 0]=np.rot90(np.flip(temp,axis=0),k=3,axes=(1,0))
    return depth_input

#建立样本后，采用旋转和翻转扩充地形特征数据
def data_augmentation_main(scnNum,sample_per_scn,patch_row_col_Num,main_input):
    temp=np.empty([patch_row_col_Num,patch_row_col_Num], dtype = float) 
    for j in range(7):    #7代表输入参数个数，修改输入参数个数时，记得修改这里
        for k in range(scnNum*sample_per_scn):
            temp[:,:]=main_input[k, :,:, j]
            main_input[scnNum*sample_per_scn+k, :,:, j]=np.rot90(temp,k=1,axes=(1,0))
            main_input[2*scnNum*sample_per_scn+k, :,:, j]=np.rot90(temp,k=2,axes=(1,0))
            main_input[3*scnNum*sample_per_scn+k, :,:, j]=np.rot90(temp,k=3,axes=(1,0))
            main_input[4*scnNum*sample_per_scn+k, :,:, j]=np.flip(temp,axis=0)
            main_input[5*scnNum*sample_per_scn+k, :,:, j]=np.rot90(np.flip(temp,axis=0),k=1,axes=(1,0))
            main_input[6*scnNum*sample_per_scn+k, :,:, j]=np.rot90(np.flip(temp,axis=0),k=2,axes=(1,0))
            main_input[7*scnNum*sample_per_scn+k, :,:, j]=np.rot90(np.flip(temp,axis=0),k=3,axes=(1,0))
    return main_input
    
#将整个研究区域处理成多个样本，作为训练好的模型的输入
#def predict_dataInput(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,inpFea_num,dem,mask,building):
def predict_dataInput(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,inpFea_num,dem,junctn,slope,aspect,curvatu,building,pipe):
    pred_dem_whole=np.empty([(patch_num_row+1)*(patch_num_col+1),patch_row_col_Num,patch_row_col_Num,inpFea_num],dtype=float)
    for j in range(patch_num_row):#行
        for k in range(patch_num_col):#列
            pred_dem_whole[j*patch_num_col+k,:,:,0]=dem[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,1]=junctn[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,2]=slope[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,3]=aspect[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,4]=curvatu[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            #pred_dem_whole[j*patch_num_col+k,:,:,5]=mask[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,5]=building[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
            pred_dem_whole[j*patch_num_col+k,:,:,6]=pipe[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    
    #补全右边和下边
    for j in range(patch_num_row):#行,python数组左闭右开
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,0]=dem[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,1]=junctn[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,2]=slope[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,3]=aspect[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,4]=curvatu[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        #pred_dem_whole[patch_num_row*patch_num_col+j,:,:,5]=mask[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,5]=building[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
        pred_dem_whole[patch_num_row*patch_num_col+j,:,:,6]=pipe[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    
    for k in range(patch_num_col):#列
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,0]=dem[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,1]=junctn[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,2]=slope[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,3]=aspect[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,4]=curvatu[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        #pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,5]=mask[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,5]=building[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,6]=pipe[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,0]=dem[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,1]=junctn[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,2]=slope[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,3]=aspect[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,4]=curvatu[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    #pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,5]=mask[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,5]=building[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,6]=pipe[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
    return pred_dem_whole

#预测结果出来后，将多个patch合成整个研究区的形状
def predict_resultCompos(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,pred):
    pred_depth_whole=np.empty([1,rowNum,colNum,1], dtype = float)
    remainder_row=rowNum%patch_row_col_Num#列方向余数，距下方
    remainder_col=colNum%patch_row_col_Num#行方向余数数，距右方
    for j in range(patch_num_row):#行
        for k in range(patch_num_col):#列
            pred_depth_whole[0,j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num,0]=pred[j*patch_num_col+k,:,:,0]
    
    for j in range(patch_num_row):#行
        pred_depth_whole[0,j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-remainder_col:colNum,0]=pred[patch_num_row*patch_num_col+j,:,patch_row_col_Num-remainder_col:patch_row_col_Num,0]
    
    for k in range(patch_num_col):#列
        pred_depth_whole[0,rowNum-remainder_row:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num,0]=pred[patch_num_row*(patch_num_col+1)+j,patch_row_col_Num-remainder_row:patch_row_col_Num,:,0]
    
    pred_depth_whole[0,rowNum-remainder_row:rowNum,colNum-remainder_col:colNum,0]=pred[(patch_num_row+1)*(patch_num_col+1)-1,patch_row_col_Num-remainder_row:patch_row_col_Num,patch_row_col_Num-remainder_col:patch_row_col_Num,0]
    return pred_depth_whole


