# -*- coding: utf-8 -*-
"""
Created on Thu Jul  8 17:08:04 2021
在new2基础上添加了dropout层，效果很好，也是首选
@author: dell
"""
import tensorflow as tf
import keras
from keras.layers import Reshape
from keras.layers import Input, Embedding, LSTM, Dense, Conv2D, Conv2DTranspose, Flatten
from keras.layers import  Activation, MaxPooling2D
from keras.layers import LeakyReLU, Dropout, ReLU
from keras.models import Model
import numpy as np
#np.random.seed(0)  # 设置随机种子，用于复现结果

def custom_loss(y_pred, y_actual, is_mean=False, name="custom_loss"):
    
    if y_pred.get_shape().ndims == 2:  # [batch_size, n_feature]
        if is_mean:
            custom_loss = tf.reduce_mean(tf.reduce_mean(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),1))
        else:
            custom_loss = tf.reduce_mean(tf.reduce_sum(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),1))
    elif y_pred.get_shape().ndims == 3:  # [batch_size, w, h]
        if is_mean:
            custom_loss = tf.reduce_mean(tf.reduce_mean(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),[1,2]))
        else:
            custom_loss = tf.reduce_mean(tf.reduce_sum(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),[1,2]))
    elif y_pred.get_shape().ndims == 4:  # [batch_size, w, h, c]
        if is_mean:
            custom_loss = tf.reduce_mean(tf.reduce_mean(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),[1,2,3]))
        else:
            custom_loss = tf.reduce_mean(tf.reduce_sum(tf.multiply(tf.exp(tf.add(y_actual,-1)),tf.square(tf.subtract(y_actual,y_pred))),[1,2,3]))
    else:
        raise Exception("Unknow dimension")
    return custom_loss

def model_build():
    # 标题输入：接收一个(24,24,7)的图片，每个数都是float格式。
    # 注意我们可以通过传递一个 "name" 参数来命名任何层。
    Main_input = Input(shape=(24,24,7), dtype='float', name='Main_input')
    
    # 模块1
    Conv11 = Conv2D(
            input_shape=(24, 24, 7),
            filters=32,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Main_input)
    Relu11=LeakyReLU(alpha=0.02)(Conv11)
    #卷积层2
    Conv12 = Conv2D(
            filters=32,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu11)
    Relu12=LeakyReLU(alpha=0.02)(Conv12)
    #池化层
    Maxpool1 = MaxPooling2D(pool_size=2,
            strides=2,
            padding='same',
            data_format='channels_last'
            )(Relu12)
    Relu13=LeakyReLU(alpha=0.02)(Maxpool1)
    #模块2
    Conv21 = Conv2D(
            filters=64,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu13)
    Relu21=LeakyReLU(alpha=0.02)(Conv21)
    #卷积层2
    Conv22 = Conv2D(
            filters=64,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu21)
    Relu22=LeakyReLU(alpha=0.02)(Conv22)
    #池化层
    Maxpool2 = MaxPooling2D(pool_size=2,
            strides=2,
            padding='same',
            data_format='channels_last'
            )(Relu22)
    Relu23=LeakyReLU(alpha=0.02)(Maxpool2)
    
    #降雨输入
    rainfall_data = Input(shape=12, name='rainfall_data')
    rainfall_dense = Dense(144, activation='sigmoid', name='rainfall_dense')(rainfall_data)
    rainfall_input = Reshape([6,6,4])(rainfall_dense)
    
    #模块4
    #将池化后的网络与降雨输入接起来
    data_conct=keras.layers.concatenate([Relu23, rainfall_input],-1)
    
    #模块5
    #转置卷积层
    Deconv51=Conv2DTranspose(
        filters=68,
        kernel_size=2,
        strides=2,
        padding="same",
        data_format='channels_last'
        )(data_conct)
    Relu51=LeakyReLU(alpha=0.02)(Deconv51)
    #卷积层
    Conv51 = Conv2D(
            filters=68,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu51)
    Relu52=LeakyReLU(alpha=0.02)(Conv51)
    #卷积层2
    Conv52 = Conv2D(
            filters=68,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu52)
    Relu53=LeakyReLU(alpha=0.02)(Conv52)
    #Dropout层
    Dp51=Dropout(0.2)(Relu53)
    #模块7
    #转置卷积层
    Deconv71=Conv2DTranspose(
        filters=32,
        kernel_size=2,
        strides=2,
        padding="same",
        data_format='channels_last'
        )(Dp51)
    Relu71=LeakyReLU(alpha=0.02)(Deconv71)
    #卷积层
    Conv71 = Conv2D(
            filters=32,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Relu71)
    Relu72=LeakyReLU(alpha=0.02)(Conv71)
    #Dropout层
    Dp71=Dropout(0.2)(Relu72)
    #卷积层2
    Conv72 = Conv2D(
            filters=1,
            kernel_size=3,
            strides=(1,1),
            padding="same",
            data_format="channels_last"
            )(Dp71)
    Relu73=LeakyReLU(alpha=0.02)(Conv72)
    Main_output=ReLU()(Relu73)
    model = Model(inputs=[Main_input, rainfall_data], outputs=Main_output)
    model.compile(optimizer='adam', loss=custom_loss, metrics=['mae'])
    return model


model=model_build()
model.summary()















