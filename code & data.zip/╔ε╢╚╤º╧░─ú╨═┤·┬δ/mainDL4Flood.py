# -*- coding: utf-8 -*-
"""
Created on Fri Mar 19 11:51:43 2021
深度学习模型的main函数，程序的入口
最新更新于2021年8月24日
@author: dell
"""

import tensorflow as tf
import math
import os
import numpy as np
from dataProcess import depth_data_process,raindata_process,normalization,normalization_reverse,data_process,data_augmentation_depth,data_augmentation_main,predict_dataInput,predict_resultCompos
from nnAPI_new4 import model_build,custom_loss
import pylab as plt

#预定义必要参数
#======================================================================================#
#数据库存放路径
dem_depth_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/dataset1.asc"  #高程和历史降雨最大水深
rain_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/rainfallData1.asc" #降雨
junctn_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/junction.asc"    #检查井位置
slope_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/slope.asc"         #坡度
aspect_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/aspect.asc"       #坡向
curvatu_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/curvatu.asc"     #曲率
#mask_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/ra.asc"             #研究区范围
building_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/building.asc"   #建筑物位置
pipe_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/pipe.asc"   #管网分布
#定义研究区的行列数
rowNum=185
colNum=197
#降雨场景数
scnNum=15
#每场降雨时段数
rain_period=12
#patch的行列数
patch_row_col_Num=24
#每个情景采样数及总采样数，8为翻转旋转之后每个样本可衍生为8个不同的样本
sample_per_scn=5000
sample_total=sample_per_scn*scnNum*8
#除降雨以外的输入特征数
inpFea_num=7
#最后预测时才用到的，行和列方向的patch数
patch_num_row=math.floor(rowNum/patch_row_col_Num)#列方向patch数
patch_num_col=math.floor(colNum/patch_row_col_Num)#行方向patch数
#存储合成的预测结果
pred_depth_whole=np.empty([1,rowNum,colNum,1], dtype = float)

#预定义存放数据矩阵
#======================================================================================#
#创建存放dem的空矩阵
dem=np.empty([rowNum,colNum], dtype = float)
#创建存放节点位置的空矩阵
junctn=np.empty([rowNum,colNum], dtype = float)
#创建存放坡度的空矩阵
slope=np.empty([rowNum,colNum], dtype = float)
#创建存放水深数据的空矩阵
depth=np.empty([scnNum,rowNum,colNum], dtype = float)
#创建存放降雨数据的空矩阵
raw_rain_data=np.empty([scnNum,rain_period], dtype = float)
temp=np.empty([patch_row_col_Num,patch_row_col_Num], dtype = float) 
#创建存放aspect的空矩阵
aspect=np.empty([rowNum,colNum], dtype = float)
#创建存放curvatu的空矩阵
curvatu=np.empty([rowNum,colNum], dtype = float)
##创建存放mask的空矩阵
#mask=np.empty([rowNum,colNum], dtype = float)
#创建存放building的空矩阵
building=np.empty([rowNum,colNum], dtype = float)
#创建存放pipe的空矩阵
pipe=np.empty([rowNum,colNum], dtype = float)
#创建存放输入数据的张量
depth_input=np.empty([sample_total,patch_row_col_Num,patch_row_col_Num,1], dtype = float)
main_input=np.empty([sample_total,patch_row_col_Num,patch_row_col_Num,inpFea_num], dtype = float)
rain_input=np.empty([sample_total,rain_period],dtype=float)
#创建存放预测时输入数据的张量
pred_dem_whole=np.empty([(patch_num_row+1)*(patch_num_col+1),patch_row_col_Num,patch_row_col_Num,inpFea_num],dtype=float)

#使用子函数读取数据并存储
#======================================================================================#
#利用data_process函数读取数据，并分类存储
dem,depth=depth_data_process(dem_depth_path)
#读取降雨数据
raw_rain_data=raindata_process(rain_path)
#读取节点数据
junctn=data_process(junctn_path)
#读取坡度数据
slope=data_process(slope_path)
#读取aspect数据
aspect=data_process(aspect_path)
#读取curvatu数据
curvatu=data_process(curvatu_path)
##读取mask数据
#mask=data_process(mask_path)
#读取building数据
building=data_process(building_path)
#读取pipe数据
pipe=data_process(pipe_path)

#原始数据预处理
#======================================================================================#
#将输入数据中的-9999修改
np.place(dem,dem==-9999,np.max(dem))
np.place(depth,depth==-9999,0)
np.place(slope,slope==-9999,0)
np.place(junctn,junctn==-9999,0)
np.place(junctn,junctn==2,1)#junction统一修改为0和1
##np.place(depth,depth<0.15,0)#depth低于0.15的设置为0
##np.place(mask,mask==0,1)
##np.place(mask,mask==-9999,0)#mask修改为0和1
np.place(aspect,aspect==-9999,0)
np.place(curvatu,curvatu==-9999,0)
np.place(building,building==-9999,0)#building修改为0和1
np.place(pipe,pipe==-9999,0)#pipe无数据的修改为0
#数据标准化,junctn、mask和building不需要标准化
depth1=depth
dem=normalization(dem)
depth=normalization(depth)
rain_data=normalization(raw_rain_data)
slope=normalization(slope)
aspect=normalization(aspect)
curvatu=normalization(curvatu)
pipe=normalization(pipe)

#将数据分为patch_row_col_Num*patch_row_col_Num*1的patch，随机生成sample_per_scn组左上角点
#======================================================================================#
for j in range(scnNum):
    for k in range(sample_per_scn):
        x=np.random.randint(0,rowNum-patch_row_col_Num)
        y=np.random.randint(0,colNum-patch_row_col_Num)
        tempxx=depth[11,x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
        if (np.sum(tempxx)==0):
            k=k-1
            continue
        else:
            depth_input[j*sample_per_scn+k, :,:, 0]=depth[j,x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 0]=dem[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 1]=junctn[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 2]=slope[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 3]=aspect[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 4]=curvatu[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            #main_input[j*sample_per_scn+k, :,:, 5]=mask[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 5]=building[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            main_input[j*sample_per_scn+k, :,:, 6]=pipe[x:x+patch_row_col_Num,y:y+patch_row_col_Num].astype('float')
            rain_input[j*sample_per_scn+k,:]=rain_data[j,:]

#数据扩张
#======================================================================================#
depth_input=data_augmentation_depth(scnNum,sample_per_scn,patch_row_col_Num,depth_input)
main_input=data_augmentation_main(scnNum,sample_per_scn,patch_row_col_Num,main_input)
for j in range(7):#这里不需要改，数据扩张1变8，所以为7
    for k in range(scnNum*sample_per_scn):
        rain_input[(j+1)*scnNum*sample_per_scn+k,:]=rain_input[k,:]
    
#创建神经网络并初始化
#======================================================================================#
model=model_build()
model.summary()
model.compile(loss=custom_loss,metrics=['mae'], optimizer='adam')

#添加tensorboard监听
#======================================================================================#
log_dir= os.path.join('logs') #win10下的bug
if not os.path.exists(log_dir):
    os.mkdir(log_dir)

checkPoint = [tf.keras.callbacks.EarlyStopping(monitor='val_loss', patience=5)]#监控val_loss参数，超过5个epoch没改进的话停止计算
              # tf.keras.callbacks.TensorBoard(log_dir = log_dir,histogram_freq=1)]#tensorboard监控频率

summary_writer = tf.summary.create_file_writer(log_dir)

#fit网络
#======================================================================================#
model.fit([main_input, rain_input], depth_input,epochs=100, batch_size=100,validation_split=0.2,verbose=1, callbacks=[checkPoint],shuffle=True)

#保存网络
#======================================================================================#
model.save('modelSaver_220828_1.h5')

#将整个研究区分成(patch_num_row+1)*(patch_num_col+1)个图片输入进去训练并集成
#======================================================================================#
pred_dem_whole=predict_dataInput(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,inpFea_num,dem,junctn,slope,aspect,curvatu,building,pipe)
#pred_dem_whole=predict_dataInput(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,inpFea_num,dem,mask,building)  
#三场降雨验证
#======================================================================================#
pred_rain_whole=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float) 
pred_rain_whole1=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float)
pred_rain_whole2=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float)
for j in range((patch_num_row+1)*(patch_num_col+1)):#行
    pred_rain_whole[j,:]=rain_data[15,:]
    pred_rain_whole1[j,:]=rain_data[16,:]
    pred_rain_whole2[j,:]=rain_data[17,:]

#采用训练好的模型进行预测
#new_model = keras.models.load_model('modelSaver.h5',custom_objects={'custom_loss': custom_loss})

#第一个预测值
#======================================================================================#
pred=model.predict([pred_dem_whole,pred_rain_whole])
pred=normalization_reverse(depth1,pred)
pred_depth_whole=predict_resultCompos(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,pred)
#画出预测值
fig = plt.figure(figsize=(10, 5))
ax = fig.add_subplot(1,1,1) # 画2行1列个图形的第1个
toplot = pred_depth_whole[0,::,::,0]
plt.imshow(toplot)
modelResult=toplot.reshape(36445,1)

#第二个预测值
#======================================================================================#
pred1=model.predict([pred_dem_whole,pred_rain_whole1])
pred1=normalization_reverse(depth1,pred1)
pred_depth_whole=predict_resultCompos(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,pred1)
#画出预测值
fig = plt.figure(figsize=(10, 5))
ax1 = fig.add_subplot(1,1,1) # 画2行1列个图形的第1个
toplot1 = pred_depth_whole[0,::,::,0]
plt.imshow(toplot1)
modelResult1=toplot1.reshape(36445,1)

#第三个预测值
#======================================================================================#
pred2=model.predict([pred_dem_whole,pred_rain_whole2])
pred2=normalization_reverse(depth1,pred2)
pred_depth_whole=predict_resultCompos(rowNum,colNum,patch_row_col_Num,patch_num_row,patch_num_col,pred2)
#画出预测值
fig = plt.figure(figsize=(10, 5))
ax2 = fig.add_subplot(1,1,1) # 画2行1列个图形的第1个
toplot2 = pred_depth_whole[0,::,::,0]
plt.imshow(toplot2)
modelResult2=toplot2.reshape(36445,1)
















