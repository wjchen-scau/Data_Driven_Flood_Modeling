
"""
Created on Thu Jul 22 17:35:37 2021
读取存储的模型参数，利用新的输入计算结果
@author: dell
"""
import keras
import math
import numpy as np
from dataProcess import depth_data_process,raindata_process,normalization,normalization_reverse,data_process
from nnAPI_new4 import custom_loss
import pylab as plt
import datetime
from matplotlib.colors import LogNorm
from matplotlib.pyplot import MultipleLocator
from pylab import *

#数据库存放路径
dem_depth_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/dataset1.asc"
rain_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/rainfallData1.asc" #rainfallDatashice中16是shice1，17是shice2
junctn_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/junction.asc"
slope_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/slope.asc"
aspect_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/aspect.asc"
curvatu_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/curvatu.asc"
#mask_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/ra.asc"
building_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/building.asc"
pipe_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/pipe.asc"   
valid_path="E:/Wenjie/CADDIES/coupleTest/DeepLearning/result3/validSet/R17.asc" #validSet数据
#定义研究区的行列数
rowNum=185
colNum=197
#降雨场景数
scnNum=15
#每场降雨时段数
rain_period=12
#patch的行列数
patch_row_col_Num=24
#每个情景采样数及总采样数，8为翻转旋转之后每个样本可衍生为8个不同的样本
sample_per_scn=5
sample_total=sample_per_scn*scnNum*8
#除降雨以外的输入特征数
inpFea_num=7
#创建存放dem的空矩阵
dem=np.empty([rowNum,colNum], dtype = float)
#创建存放节点位置的空矩阵
junctn=np.empty([rowNum,colNum], dtype = float)
#创建存放坡度的空矩阵
slope=np.empty([rowNum,colNum], dtype = float)
#创建存放水深数据的空矩阵
depth=np.empty([scnNum,rowNum,colNum], dtype = float)
#创建存放降雨数据的空矩阵
raw_rain_data=np.empty([scnNum,rain_period], dtype = float)
temp=np.empty([patch_row_col_Num,patch_row_col_Num], dtype = float) 
#创建存放aspect的空矩阵
aspect=np.empty([rowNum,colNum], dtype = float) 
#创建存放curvatu的空矩阵
curvatu=np.empty([rowNum,colNum], dtype = float)
##创建存放mask的空矩阵
#mask=np.empty([rowNum,colNum], dtype = float)
#创建存放building的空矩阵
building=np.empty([rowNum,colNum], dtype = float)
#创建存放pipe的空矩阵
pipe=np.empty([rowNum,colNum], dtype = float)
validdepth=np.empty([rowNum,colNum], dtype = float)

#利用data_process函数读取数据，并分类存储
dem,depth=depth_data_process(dem_depth_path)
#读取降雨数据
raw_rain_data=raindata_process(rain_path)
#读取节点数据
junctn=data_process(junctn_path)
#读取坡度数据
slope=data_process(slope_path)
#读取aspect数据
aspect=data_process(aspect_path)
#读取curvatu数据
curvatu=data_process(curvatu_path)
##读取mask数据
#mask=data_process(mask_path)
#读取building数据
building=data_process(building_path)
#读取pipe数据
pipe=data_process(pipe_path)
validdepth=data_process(valid_path)

#原始数据预处理
#======================================================================================#
#将输入数据中的-9999修改
np.place(dem,dem==-9999,np.max(dem))
np.place(depth,depth==-9999,0)
np.place(slope,slope==-9999,0)
np.place(junctn,junctn==-9999,0)
np.place(junctn,junctn==2,1)#junction统一修改为0和1
##np.place(depth,depth<0.15,0)#depth低于0.15的设置为0
##np.place(mask,mask==0,1)
##np.place(mask,mask==-9999,0)#mask修改为0和1
np.place(aspect,aspect==-9999,0)
np.place(curvatu,curvatu==-9999,0)
np.place(building,building==-9999,0)#building修改为0和1
np.place(pipe,pipe==-9999,0)#pipe无数据的修改为0
#数据标准化,junctn、mask和building不需要标准化
depth1=depth
dem=normalization(dem)
depth=normalization(depth)
rain_data=normalization(raw_rain_data)
slope=normalization(slope)
aspect=normalization(aspect)
curvatu=normalization(curvatu)
pipe=normalization(pipe)

#将整个研究区分成7*8=56个图片输入进去训练并集成
patch_num_row=math.floor(rowNum/patch_row_col_Num)#列方向patch数
patch_num_col=math.floor(colNum/patch_row_col_Num)#行方向patch数

pred_dem_whole=np.empty([(patch_num_row+1)*(patch_num_col+1),patch_row_col_Num,patch_row_col_Num,inpFea_num],dtype=float)

for j in range(patch_num_row):#行
    for k in range(patch_num_col):#列
        pred_dem_whole[j*patch_num_col+k,:,:,0]=dem[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,1]=junctn[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,2]=slope[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,3]=aspect[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,4]=curvatu[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        #pred_dem_whole[j*patch_num_col+k,:,:,5]=mask[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,5]=building[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
        pred_dem_whole[j*patch_num_col+k,:,:,6]=pipe[j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')

#补全右边和下边
for j in range(patch_num_row):#行,python数组左闭右开
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,0]=dem[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,1]=junctn[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,2]=slope[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,3]=aspect[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,4]=curvatu[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    #pred_dem_whole[patch_num_row*patch_num_col+j,:,:,5]=mask[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,5]=building[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')
    pred_dem_whole[patch_num_row*patch_num_col+j,:,:,6]=pipe[j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-patch_row_col_Num:colNum].astype('float')

for k in range(patch_num_col):#列
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,0]=dem[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,1]=junctn[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,2]=slope[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,3]=aspect[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,4]=curvatu[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    #pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,5]=mask[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,5]=building[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    pred_dem_whole[patch_num_row*(patch_num_col+1)+k,:,:,6]=pipe[rowNum-patch_row_col_Num:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num].astype('float')
    
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,0]=dem[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,1]=junctn[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,2]=slope[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,3]=aspect[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,4]=curvatu[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
#pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,5]=mask[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,5]=building[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
pred_dem_whole[(patch_num_row+1)*(patch_num_col+1)-1,:,:,6]=pipe[rowNum-patch_row_col_Num:rowNum,colNum-patch_row_col_Num:colNum].astype('float')
        
pred_rain_whole=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float) 
pred_rain_whole1=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float)
pred_rain_whole2=np.empty([(patch_num_row+1)*(patch_num_col+1),rain_period], dtype = float)

for j in range((patch_num_row+1)*(patch_num_col+1)):#行
    pred_rain_whole[j,:]=rain_data[15,:]
    pred_rain_whole1[j,:]=rain_data[16,:]
    pred_rain_whole2[j,:]=rain_data[17,:]
    
#存储合成结果
pred_depth_whole=np.empty([1,rowNum,colNum,1], dtype = float)

start = datetime.datetime.now()

#采用训练好的模型进行预测
new_model = keras.models.load_model('modelSaver_220827.h5',custom_objects={'custom_loss': custom_loss})

remainder_row=rowNum%patch_row_col_Num#列方向余数，距下方
remainder_col=colNum%patch_row_col_Num#行方向余数数，距右方

#第三个预测值
pred2=new_model.predict([pred_dem_whole,pred_rain_whole2])
pred2=normalization_reverse(depth1,pred2)

end = datetime.datetime.now()
print("Running time: %s seconds"%(end - start))

for j in range(patch_num_row):#行
    for k in range(patch_num_col):#列
        pred_depth_whole[0,j*patch_row_col_Num:(j+1)*patch_row_col_Num,k*patch_row_col_Num:(k+1)*patch_row_col_Num,0]=pred2[j*patch_num_col+k,:,:,0]

for j in range(patch_num_row):#行
    pred_depth_whole[0,j*patch_row_col_Num:(j+1)*patch_row_col_Num,colNum-remainder_col:colNum,0]=pred2[patch_num_row*patch_num_col+j,:,patch_row_col_Num-remainder_col:patch_row_col_Num,0]

for k in range(patch_num_col):#列
    pred_depth_whole[0,rowNum-remainder_row:rowNum,k*patch_row_col_Num:(k+1)*patch_row_col_Num,0]=pred2[patch_num_row*(patch_num_col+1)+j,patch_row_col_Num-remainder_row:patch_row_col_Num,:,0]

pred_depth_whole[0,rowNum-remainder_row:rowNum,colNum-remainder_col:colNum,0]=pred2[(patch_num_row+1)*(patch_num_col+1)-1,patch_row_col_Num-remainder_row:patch_row_col_Num,patch_row_col_Num-remainder_col:patch_row_col_Num,0]

#画出预测值

toplot1 = pred_depth_whole[0,::,::,0]
np.place(toplot1,toplot1<0,0)
np.savetxt(r'DHC_7inp_R17.txt', toplot1, fmt='%f',delimiter=' ')
#画对比图
modelResult1=toplot1.reshape(36445,1)
result1=validdepth.reshape(36445,1)
x=np.empty([36445], dtype = float)
y=np.empty([36445], dtype = float)
for k in range(36445):
    x[k]=result1[k,0].astype('float')
    y[k]=modelResult1[k,0].astype('float')
    
fig = plt.figure()
ax = fig.add_subplot(1,1,1)
font1={'family':'Times New Roman', 'weight':'normal','size':13,}
font2={'family':'Times New Roman', 'weight':'bold','size':15,}
plt.hist2d(x, y, bins=100, norm=LogNorm())
plt.xlim(0,1.5)
plt.ylim(0,1.5)
xmajorLocator  = MultipleLocator(0.5)
ymajorLocator  = MultipleLocator(0.5)
ax.xaxis.grid(False) #x坐标轴的网格使用主刻度
ax.yaxis.grid(False) #y坐标轴的网格使用次刻度
plt.tick_params(labelsize=13)
ax.xaxis.set_major_locator(xmajorLocator)
ax.yaxis.set_major_locator(ymajorLocator)
labels = ax.get_xticklabels() + ax.get_yticklabels()
[label.set_fontname('Times New Roman') for label in labels]
cb=plt.colorbar()
cb.set_label('Density',fontdict=font1)
cb.ax.tick_params(labelsize=13)
cb_labels = cb.ax.get_yticklabels()
[cb_label.set_fontname('Times New Roman') for cb_label in cb_labels]
plt.title('Historical Rainfall2',font2)
plt.xlabel('HM',font1)
plt.ylabel('DLM',font1)
x1=[0,1,1.5]
y1=[0,1,1.5]
plt.plot(x1,y1,linewidth = 1)
#plt.savefig(r'E:\Wenjie\deepLearning_floodMapping\manuscript\figure\DHC内涝深度对比图\DHC_HisRain2.png', dpi=300)
plt.show()






